/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package controller;

/**
 *
 * @author Administrator
 */

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;
import model.Product;
import model.ProductManager;
import model.SortOption;
import utils.PriceUtil;
import view.MainUI;

public class ProductController {
    private static final String[] DEFAULT_CATEGORIES =
            {"General", "Electronics", "Groceries", "Clothing", "Office Supplies"};

    private final ProductManager model;
    private MainUI view;
    private String lastError = "";

    public ProductController(ProductManager model) {
        this.model = model;
    }

    public void setView(MainUI view) {
        this.view = view;
    }

    /** Reason why the last handleXxx call returned false (show it in a dialog). */
    public String getLastError() {
        return lastError;
    }

    /**
     * Add a new product using the details from the view
     *
     * @return true - if adding the new Product object is successful
     * @return false - if validation or saving fails (see getLastError())
     */
    public boolean handleAddProduct(String name, String desc, String priceText, String category) {
        //1. validation
        if (PriceUtil.isBlank(name)) {
            return fail("Product name is required.");
        }
        BigDecimal price;
        try {
            price = PriceUtil.parsePrice(priceText);
        } catch (IllegalArgumentException e) {
            return fail(e.getMessage());
        }
        if (model.nameExists(name.trim(), null)) {
            return fail("A product with this name already exists.");
        }
        //2. create new product object and let the model hold it
        Product product = new Product(name.trim(), safe(desc), price, normalizeCategory(category));
        this.model.addProduct(product);
        //3. save the changes to file for persistence
        if (this.model.saveProducts() == -1) {
            this.model.deleteProduct(product.getProductId());
            return fail("Could not save the product to file.");
        }
        //4. update the view to reflect changes
        refreshView();
        return true;
    }

    /**
     * Update the product information using the info from the view
     */
    public boolean handleUpdateProduct(String id, String name, String desc, String priceText, String category) {
        if (PriceUtil.isBlank(name)) {
            return fail("Product name is required.");
        }
        BigDecimal price;
        try {
            price = PriceUtil.parsePrice(priceText);
        } catch (IllegalArgumentException e) {
            return fail(e.getMessage());
        }
        Product product = this.model.findProduct(id);
        if (product == null) {
            return fail("Product not found.");
        }
        if (model.nameExists(name.trim(), id)) {
            return fail("A product with this name already exists.");
        }
        product.setProductName(name.trim());
        product.setProductDesc(safe(desc));
        product.setProductPrice(price);
        product.setCategory(normalizeCategory(category));

        if (this.model.saveProducts() == -1) {
            return fail("Could not save the changes to file.");
        }
        refreshView();
        return true;
    }

    /**
     * Delete the product given the String id
     */
    public boolean handleDeleteProduct(String id) {
        Product product = this.model.deleteProduct(id);
        if (product != null) {
            this.model.saveProducts(); //persist change
            System.out.println("Deleted Product: " + product);
            refreshView();
            return true;
        } else {
            return fail("Product not found.");
        }
    }

    /**
     * Retrieves the products that match the search text (name, description or
     * category), sorted using the chosen option.
     * Default order: PRICE_LOW_TO_HIGH (cheapest first).
     */
    public List<Product> getAllProducts(String searchText, SortOption sortOption) {
        String q = searchText == null ? "" : searchText.trim().toLowerCase();
        List<Product> list = new ArrayList<>();
        for (Product p : this.model.findAll().values()) {
            if (q.isEmpty()
                    || p.getProductName().toLowerCase().contains(q)
                    || p.getProductDesc().toLowerCase().contains(q)
                    || p.getCategory().toLowerCase().contains(q)) {
                list.add(p);
            }
        }
        SortOption option = sortOption == null ? SortOption.PRICE_LOW_TO_HIGH : sortOption;
        list.sort(option.getComparator());
        return list;
    }

    /**
     * Retrieves a specific Product object from the model to display its details in the View.
     */
    public Product getProductDetails(String id) {
        return model.findProduct(id);
    }

    /** Default categories plus any category already used by a product. */
    public List<String> getCategories() {
        TreeSet<String> set = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        set.addAll(Arrays.asList(DEFAULT_CATEGORIES));
        for (Product p : model.findAll().values()) {
            set.add(p.getCategory());
        }
        return new ArrayList<>(set);
    }

    // ---------------------------------------------------------------- helpers
    private String normalizeCategory(String category) {
        return PriceUtil.isBlank(category) ? "Uncategorized" : category.trim();
    }

    private String safe(String s) {
        return s == null ? "" : s.trim();
    }

    private boolean fail(String message) {
        this.lastError = message;
        return false;
    }

    private void refreshView() {
        if (this.view != null) {
            this.view.refreshProducts();
        }
    }
}
