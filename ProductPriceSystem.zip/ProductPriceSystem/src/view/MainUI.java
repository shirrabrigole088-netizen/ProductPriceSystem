/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package view;

/**
 *
 * @author Administrator
 */
import controller.ProductController;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumnModel;
import model.Product;
import model.SortOption;
import utils.PriceUtil;

/**
 * Main window of the Product Price System.
 *
 * Component names (same style as NetBeans' defaults):
 *   Details : jTFProductName, jTFPrice, jComboCategory, jTADescription
 *   Buttons : jBtnAdd, jBtnUpdate, jBtnDelete, jBtnClear
 *   Search  : jTFSearch, jComboSortBy
 *   Table   : jTableProducts, jLabelSummary
 *
 * TIP: if you prefer to keep your own NetBeans-designed form, keep your designer's
 * initComponents() and copy everything from "setupListTable()" down to the end of the
 * event handlers into your class, then rename the variables above to match yours.
 */
public class MainUI extends JFrame {

    private static final String TITLE = "Product Price System";

    private final ProductController controller;
    private final ProductTableModel tableModel;
    private String selectedProductId;

    public MainUI(ProductController controller) {
        this.controller = controller;
        this.tableModel = new ProductTableModel();

        initComponents();
        setupListTable();
        setupRowsActionListener();
        setupSearchAndSort();
        setUpDefaults();

        refreshProducts();
    }

    // ------------------------------------------------------------------
    // UI LAYOUT (replaces the designer-generated initComponents)
    // ------------------------------------------------------------------
    private void initComponents() {
        setTitle(TITLE);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        // --- Title ---
        JLabel jLabelTitle = new JLabel("Product Price System", SwingConstants.CENTER);
        jLabelTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));

        // --- Product Details ---
        jTFProductName = new JTextField(20);
        jTFPrice = new JTextField("0.00", 10);
        jTFPrice.setHorizontalAlignment(JTextField.TRAILING);
        jComboCategory = new JComboBox<>(new DefaultComboBoxModel<>(controller.getCategories().toArray(new String[0])));
        jComboCategory.setEditable(true); // type a new category or pick an existing one
        jTADescription = new JTextArea(3, 20);
        jTADescription.setLineWrap(true);
        jTADescription.setWrapStyleWord(true);
        JScrollPane descScroll = new JScrollPane(jTADescription);

        JPanel detailsPanel = new JPanel(new GridBagLayout());
        detailsPanel.setBorder(BorderFactory.createTitledBorder("Product Details"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 6, 4, 6);
        g.anchor = GridBagConstraints.WEST;
        g.fill = GridBagConstraints.HORIZONTAL;

        g.gridx = 0; g.gridy = 0; g.weightx = 0;
        detailsPanel.add(new JLabel("Name:"), g);
        g.gridx = 1; g.weightx = 1;
        detailsPanel.add(jTFProductName, g);
        g.gridx = 2; g.weightx = 0;
        detailsPanel.add(new JLabel("Price (\u20B1):"), g);
        g.gridx = 3; g.weightx = 0.3;
        detailsPanel.add(jTFPrice, g);

        g.gridx = 0; g.gridy = 1; g.weightx = 0;
        detailsPanel.add(new JLabel("Category:"), g);
        g.gridx = 1; g.weightx = 1;
        detailsPanel.add(jComboCategory, g);

        g.gridx = 0; g.gridy = 2; g.weightx = 0; g.anchor = GridBagConstraints.NORTHWEST;
        detailsPanel.add(new JLabel("Description:"), g);
        g.gridx = 1; g.gridwidth = 3; g.weightx = 1; g.anchor = GridBagConstraints.WEST;
        detailsPanel.add(descScroll, g);

        // --- Buttons ---
        jBtnAdd = new JButton("Add");
        jBtnUpdate = new JButton("Update");
        jBtnDelete = new JButton("Delete");
        jBtnClear = new JButton("Clear");
        jBtnAdd.addActionListener(this::jBtnAddActionPerformed);
        jBtnUpdate.addActionListener(this::jBtnUpdateActionPerformed);
        jBtnDelete.addActionListener(this::jBtnDeleteActionPerformed);
        jBtnClear.addActionListener(this::jBtnClearActionPerformed);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 4));
        buttonPanel.add(jBtnAdd);
        buttonPanel.add(jBtnUpdate);
        buttonPanel.add(jBtnDelete);
        buttonPanel.add(jBtnClear);

        // --- Search & Sort ---
        jTFSearch = new JTextField(20);
        jComboSortBy = new JComboBox<>(new DefaultComboBoxModel<>(SortOption.values())); // first = cheapest to most expensive

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search & Sort"));
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(jTFSearch);
        searchPanel.add(new JLabel("Sort by:"));
        searchPanel.add(jComboSortBy);

        JPanel topPanel = new JPanel(new BorderLayout(0, 4));
        topPanel.add(detailsPanel, BorderLayout.NORTH);
        topPanel.add(buttonPanel, BorderLayout.CENTER);
        topPanel.add(searchPanel, BorderLayout.SOUTH);

        // --- Products table ---
        jTableProducts = new JTable();
        JScrollPane scrollPane = new JScrollPane(jTableProducts);
        scrollPane.setPreferredSize(new Dimension(820, 240));
        jLabelSummary = new JLabel(" ");
        jLabelSummary.setBorder(BorderFactory.createEmptyBorder(4, 6, 2, 6));

        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Products"));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        tablePanel.add(jLabelSummary, BorderLayout.SOUTH);

        // --- Frame ---
        getContentPane().setLayout(new BorderLayout(0, 6));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        getContentPane().add(jLabelTitle, BorderLayout.NORTH);
        JPanel center = new JPanel(new BorderLayout(0, 6));
        center.add(topPanel, BorderLayout.NORTH);
        center.add(tablePanel, BorderLayout.CENTER);
        getContentPane().add(center, BorderLayout.CENTER);

        pack();
        setMinimumSize(getSize());
        setLocationRelativeTo(null);
    }

    // ------------------------------------------------------------------
    // SETUP
    // ------------------------------------------------------------------
    //setup table model
    private void setupListTable() {
        jTableProducts.setModel(tableModel);
        jTableProducts.getTableHeader().setReorderingAllowed(false);
        jTableProducts.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jTableProducts.setAutoCreateColumnsFromModel(true);
        jTableProducts.createDefaultColumnsFromModel();
        setupTableColumnWidths();
    }

    private void setupTableColumnWidths() {
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);

        TableColumnModel columnModel = jTableProducts.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(100); // Product ID
        columnModel.getColumn(1).setPreferredWidth(180); // Name
        columnModel.getColumn(2).setPreferredWidth(250); // Description
        columnModel.getColumn(3).setPreferredWidth(110); // Price
        columnModel.getColumn(4).setPreferredWidth(110); // Category
        columnModel.getColumn(3).setCellRenderer(rightRenderer);
        jTableProducts.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
    }

    //when a row is selected, show its details in the form
    private void setupRowsActionListener() {
        jTableProducts.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) {
                return;
            }
            int selectedRow = jTableProducts.getSelectedRow();
            if (selectedRow != -1) {
                int modelRow = jTableProducts.convertRowIndexToModel(selectedRow);
                String productId = this.tableModel.getProductId(modelRow);
                Product selected = controller.getProductDetails(productId);
                if (selected != null) {
                    displaySelectedProduct(selected);
                }
            }
        });
    }

    //live search + sort
    private void setupSearchAndSort() {
        jTFSearch.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { refreshProducts(); }
            @Override
            public void removeUpdate(DocumentEvent e) { refreshProducts(); }
            @Override
            public void changedUpdate(DocumentEvent e) { refreshProducts(); }
        });
        jComboSortBy.addActionListener(e -> refreshProducts());
    }

    //default display
    private void setUpDefaults() {
        this.selectedProductId = null;
        jTableProducts.clearSelection();

        //default fields
        this.jTFProductName.setText("");
        this.jTADescription.setText("");
        this.jTFPrice.setText("0.00");
        this.jComboCategory.setSelectedItem("General");

        //default buttons
        this.jBtnAdd.setEnabled(true);
        this.jBtnUpdate.setEnabled(false);
        this.jBtnDelete.setEnabled(false);

        this.jTFProductName.requestFocusInWindow();
    }

    private void displaySelectedProduct(Product product) {
        this.jTFProductName.setText(product.getProductName());
        this.jTADescription.setText(product.getProductDesc());
        this.jTFPrice.setText(PriceUtil.plain(product.getProductPrice()));
        this.jComboCategory.setSelectedItem(product.getCategory());
        this.selectedProductId = product.getProductId();

        // set display for buttons
        this.jBtnAdd.setEnabled(false);
        this.jBtnUpdate.setEnabled(true);
        this.jBtnDelete.setEnabled(true);
    }

    private String getCategoryText() {
        Object item = jComboCategory.getEditor().getItem();
        return item == null ? "" : item.toString();
    }

    //make sure every category in use is available in the combo box
    private void syncCategories() {
        DefaultComboBoxModel<String> model = (DefaultComboBoxModel<String>) jComboCategory.getModel();
        for (String category : controller.getCategories()) {
            if (model.getIndexOf(category) == -1) {
                model.addElement(category);
            }
        }
    }

    //refresh products (called by the controller after every change)
    public void refreshProducts() {
        String savedSelectedId = this.selectedProductId;

        syncCategories();

        SortOption sortOption = (SortOption) jComboSortBy.getSelectedItem();
        List<Product> products = controller.getAllProducts(jTFSearch.getText(), sortOption);

        //update the table model
        this.tableModel.setProducts(products);
        updateSummary(products);

        //keep the previously selected product selected, if it is still listed
        if (savedSelectedId != null) {
            int newModelRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (savedSelectedId.equals(tableModel.getProductId(i))) {
                    newModelRow = i;
                    break;
                }
            }
            if (newModelRow != -1) {
                int newTableRow = jTableProducts.convertRowIndexToView(newModelRow);
                jTableProducts.setRowSelectionInterval(newTableRow, newTableRow);
            } else {
                setUpDefaults();
            }
        }
    }

    //"3 product(s) | Cheapest: Pen (PHP 12.00) | Most expensive: Bag (PHP 899.00)"
    private void updateSummary(List<Product> products) {
        if (products.isEmpty()) {
            jLabelSummary.setText("No products to show.");
            return;
        }
        Product cheapest = products.get(0);
        Product priciest = products.get(0);
        for (Product p : products) {
            if (p.getProductPrice().compareTo(cheapest.getProductPrice()) < 0) {
                cheapest = p;
            }
            if (p.getProductPrice().compareTo(priciest.getProductPrice()) > 0) {
                priciest = p;
            }
        }
        jLabelSummary.setText(products.size() + " product(s)   |   Cheapest: "
                + cheapest.getProductName() + " (" + PriceUtil.format(cheapest.getProductPrice()) + ")"
                + "   |   Most expensive: "
                + priciest.getProductName() + " (" + PriceUtil.format(priciest.getProductPrice()) + ")");
    }

    // ------------------------------------------------------------------
    // EVENT HANDLERS
    // ------------------------------------------------------------------
    private void jBtnAddActionPerformed(ActionEvent evt) {
        boolean res = controller.handleAddProduct(
                jTFProductName.getText(),
                jTADescription.getText(),
                jTFPrice.getText(),
                getCategoryText());

        if (res) {
            JOptionPane.showMessageDialog(this, "New product added", TITLE, JOptionPane.INFORMATION_MESSAGE);
            setUpDefaults();
        } else {
            JOptionPane.showMessageDialog(this, controller.getLastError(), TITLE, JOptionPane.ERROR_MESSAGE);
        }
    }

    private void jBtnUpdateActionPerformed(ActionEvent evt) {
        if (selectedProductId == null) {
            return;
        }
        boolean res = controller.handleUpdateProduct(
                selectedProductId,
                jTFProductName.getText(),
                jTADescription.getText(),
                jTFPrice.getText(),
                getCategoryText());

        if (res) {
            JOptionPane.showMessageDialog(this, "Product updated", TITLE, JOptionPane.INFORMATION_MESSAGE);
            setUpDefaults();
        } else {
            JOptionPane.showMessageDialog(this, controller.getLastError(), TITLE, JOptionPane.ERROR_MESSAGE);
        }
    }

    private void jBtnDeleteActionPerformed(ActionEvent evt) {
        if (selectedProductId == null) {
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete \"" + jTFProductName.getText() + "\"?",
                TITLE, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        boolean res = controller.handleDeleteProduct(selectedProductId);
        if (res) {
            JOptionPane.showMessageDialog(this, "Product deleted", TITLE, JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, controller.getLastError(), TITLE, JOptionPane.ERROR_MESSAGE);
        }
        setUpDefaults();
    }

    private void jBtnClearActionPerformed(ActionEvent evt) {
        setUpDefaults();
    }

    // ------------------------------------------------------------------
    // VARIABLES
    // ------------------------------------------------------------------
    private JTextField jTFProductName;
    private JTextField jTFPrice;
    private JComboBox<String> jComboCategory;
    private JTextArea jTADescription;

    private JButton jBtnAdd;
    private JButton jBtnUpdate;
    private JButton jBtnDelete;
    private JButton jBtnClear;

    private JTextField jTFSearch;
    private JComboBox<SortOption> jComboSortBy;

    private JTable jTableProducts;
    private JLabel jLabelSummary;
}
