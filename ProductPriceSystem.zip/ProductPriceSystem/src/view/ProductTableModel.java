
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package view;

/**
 *
 * @author Administrator
 */
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.Product;
import utils.PriceUtil;

public class ProductTableModel extends AbstractTableModel {
    private List<Product> products;
    private final String[] COLUMN_NAMES = {"Product ID", "Name", "Description", "Price", "Category"};

    public ProductTableModel() {
        this.products = new ArrayList<>();
    }

    @Override
    public int getRowCount() {
        return products.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMN_NAMES.length;
    }

    @Override
    public String getColumnName(int column) {
        return COLUMN_NAMES[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Product p = products.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> p.getProductId();
            case 1 -> p.getProductName();
            case 2 -> p.getProductDesc();
            case 3 -> PriceUtil.format(p.getProductPrice());
            case 4 -> p.getCategory();
            default -> null;
        };
    }

    public void setProducts(List<Product> products) {
        this.products = products;
        fireTableDataChanged();
    }

    public String getProductId(int rowIndex) {
        return products.get(rowIndex).getProductId();
    }
}
