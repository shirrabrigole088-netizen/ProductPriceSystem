/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package utils;

/**
 *
 * @author Administrator
 */
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

/** Parsing / formatting helpers for prices (kept as BigDecimal so money math is exact). */
public class PriceUtil {
    private static final BigDecimal MAX_PRICE = new BigDecimal("999999999.99");

    /**
     * Converts what the user typed ("1,250.5", "PHP99", "99") to a BigDecimal with 2 decimals.
     *
     * @throws IllegalArgumentException with a user-friendly message if the text is not a valid price
     */
    public static BigDecimal parsePrice(String text) {
        if (text == null || text.trim().isEmpty()) {
            throw new IllegalArgumentException("Price is required.");
        }
        String cleaned = text.trim().replace(",", "").replace("\u20B1", "").replace("PHP", "").trim();
        BigDecimal price;
        try {
            price = new BigDecimal(cleaned);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Price must be a number (e.g. 149.50).");
        }
        if (price.signum() < 0) {
            throw new IllegalArgumentException("Price cannot be negative.");
        }
        price = price.setScale(2, RoundingMode.HALF_UP);
        if (price.compareTo(MAX_PRICE) > 0) {
            throw new IllegalArgumentException("Price is too large.");
        }
        return price;
    }

    /** Display format, e.g. PHP 1,250.50 */
    public static String format(BigDecimal price) {
        return NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-PH")).format(price);
    }

    /** Plain format for text fields, e.g. 1250.50 */
    public static String plain(BigDecimal price) {
        return price.setScale(2, RoundingMode.HALF_UP).toPlainString();
    }

    public static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
