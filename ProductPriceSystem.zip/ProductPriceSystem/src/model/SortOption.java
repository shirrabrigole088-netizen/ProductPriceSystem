/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package model;

/**
 *
 * @author Administrator
 */
import java.util.Comparator;

/** The ways the product list can be sorted (shown in the "Sort by" combo box). */
public enum SortOption {
    PRICE_LOW_TO_HIGH("Price: Cheapest to Most Expensive",
            Comparator.comparing(Product::getProductPrice)
                    .thenComparing(p -> p.getProductName().toLowerCase())),

    PRICE_HIGH_TO_LOW("Price: Most Expensive to Cheapest",
            Comparator.comparing(Product::getProductPrice).reversed()
                    .thenComparing(p -> p.getProductName().toLowerCase())),

    NAME_A_TO_Z("Name: A to Z",
            Comparator.comparing((Product p) -> p.getProductName().toLowerCase())),

    NAME_Z_TO_A("Name: Z to A",
            Comparator.comparing((Product p) -> p.getProductName().toLowerCase()).reversed());

    private final String label;
    private final Comparator<Product> comparator;

    SortOption(String label, Comparator<Product> comparator) {
        this.label = label;
        this.comparator = comparator;
    }

    public Comparator<Product> getComparator() {
        return comparator;
    }

    @Override
    public String toString() {
        return label; // the combo box displays this
    }
}
