/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package model;

/**
 *
 * @author Administrator
 */
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import utils.FileDBHelper;

/** Holds all products in memory and persists them to app/data/products.ser */
public class ProductManager {
    private HashMap<String, Product> products;
    private final String FILE_PATH = "products.ser";

    public ProductManager() {
        products = new HashMap<>();
        FileDBHelper.createFile(FILE_PATH);
    }

    public void addProduct(Product product) {
        products.put(product.getProductId(), product);
    }

    public Product findProduct(String id) {
        return products.get(id);
    }

    public Product deleteProduct(String id) {
        return products.remove(id);
    }

    /** @param excludeId product to ignore (used when updating), or null */
    public boolean nameExists(String name, String excludeId) {
        for (Product p : products.values()) {
            if (p.getProductId().equals(excludeId)) {
                continue;
            }
            if (p.getProductName().equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }

    public int saveProducts() {
        int errorCode = 0; //0:success; -1:error
        try (FileOutputStream fos = new FileOutputStream(FileDBHelper.DIRECTORY + FILE_PATH);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(products);
        } catch (IOException e) {
            errorCode = -1;
            System.out.println("Error: " + e);
        }
        return errorCode;
    }

    @SuppressWarnings("unchecked")
    public void loadProducts() {
        File file = new File(FileDBHelper.DIRECTORY + FILE_PATH);
        if (!file.exists() || file.length() == 0) {
            return; // nothing saved yet
        }
        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            this.products = (HashMap<String, Product>) ois.readObject();
        } catch (EOFException e) {
            // empty/partial file: start fresh
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error Read: " + e);
        }
    }

    public HashMap<String, Product> findAll() {
        return this.products;
    }
}
