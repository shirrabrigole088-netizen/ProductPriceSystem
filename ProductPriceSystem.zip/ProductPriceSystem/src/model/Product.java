/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package model;

/**
 *
 * @author Administrator
 */
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.UUID;

public class Product implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String productId;
    private String productName;
    private String productDesc;
    private BigDecimal productPrice;
    private String category;

    public Product(String productName, String productDesc, BigDecimal productPrice, String category) {
        this.productId = generateId();
        this.productName = productName;
        this.productDesc = productDesc;
        this.productPrice = productPrice;
        this.category = category;
    }

    private String generateId() {
        return "PRD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    public String getProductId() { return productId; }
    public String getProductName() { return productName; }
    public String getProductDesc() { return productDesc; }
    public BigDecimal getProductPrice() { return productPrice; }
    public String getCategory() { return category; }

    public void setProductName(String productName) { this.productName = productName; }
    public void setProductDesc(String productDesc) { this.productDesc = productDesc; }
    public void setProductPrice(BigDecimal productPrice) { this.productPrice = productPrice; }
    public void setCategory(String category) { this.category = category; }

    @Override
    public String toString() {
        return "Product{" + "productId=" + productId + ", productName=" + productName
                + ", productDesc=" + productDesc + ", productPrice=" + productPrice
                + ", category=" + category + '}';
    }
}
